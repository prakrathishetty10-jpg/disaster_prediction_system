from tkinter import *
from tkinter import messagebox
import pymysql

con = pymysql.connect(host='localhost', user='root', password='root')
sql = con.cursor()
sql.execute('use mini_project')

#functions
def clear():
    t1.delete(0, END)
    t2.delete(0, END)

def register_page():
    root.destroy()
    import demo_register

def dashboard_page():
    root.destroy()
    import my_dashboard

def login():
    if t1.get()=='' or t2.get()=='':
        messagebox.showerror('Invalid', 'All fields are required!')
    else:
        username = t1.get()
        password = t2.get()
        q1 = 'select * from users where username = %s and pass = %s'
        sql.execute(q1, (username, password))
        row = sql.fetchone()
        if row != None:
            clear()
            dashboard_page()
        else:
            messagebox.showerror('Invalid', 'Wrong Username or Password')
        
#main code
root = Tk()
root.geometry('904x604+230+50')
root.title("Login")
root.resizable(False, False)

r_bg = PhotoImage(file='7.png')
r_bg2 = Label(image=r_bg)
r_bg2.grid(row=0, column=0)

l1 = Label(root, text='Login Form', bg='white', fg='blue', font=('Arial', 15, 'bold'))
l1.place(x=588, y=110)

l2 = Label(root, text='Username', bg='white', fg='blue', font=('Arial', 10, 'bold'))
l2.place(x=500, y=180)

t1 = Entry(root, width=50)
t1.place(x=500, y=200)


l3 = Label(root, text='Password', bg='white', fg='blue', font=('Arial', 10, 'bold'))
l3.place(x=500, y=230)

t2 = Entry(root, width=50, show='*')
t2.place(x=500, y=250)



btn1 = Button(root, text='Login', bg='blue', font=('', 13, 'bold'), width=30, fg='white', cursor='hand2', command=login)
btn1.place(x=500, y=350)

l5 = Label(root, text='New User?', bg='white', fg='blue', font=('Arial', 10, ''))
l5.place(x=530, y=400)

btn2 = Button(root, text='Register Now', bg='white', font=('', 10, 'bold'), fg='blue', bd=0, activebackground='white', cursor='hand2', command=register_page)
btn2.place(x=600, y=397)

root.mainloop()
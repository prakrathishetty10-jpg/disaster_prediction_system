from tkinter import *
from tkinter import messagebox
import pymysql

con = pymysql.connect(host='localhost', user='root', password='root')
sql = con.cursor()
sql.execute('use mini_project')

#functions
def clear():
    t1.delete(0, END)
    t2.delete(0, END)
    t3.delete(0, END)

def login_page():
    root.destroy()
    import demo_login

def register():
    if t1.get()=='' or t2.get()=='' or t3.get()=='':
        messagebox.showerror('Invalid', 'All fields are required!')
    elif t2.get() != t3.get():
        messagebox.showerror('Invalid', 'Password mismatch!')
    else:
        username = t1.get()
        password = t2.get()
        q1 = 'select * from users where username = %s'
        sql.execute(q1, (username))
        row = sql.fetchone()
        if row != None:
            messagebox.showerror('Invalid', 'Username already registered!')
        else:
            q2 = 'insert into users(username, pass) values(%s, %s)'
            sql.execute(q2, (username, password))
            con.commit()
            clear()
            messagebox.showinfo('Success', 'You are successfully registered.')
            login_page()




        
#main code
root = Tk()
root.geometry('904x604+230+50')
root.title("Register")
root.resizable(False, False)

r_bg = PhotoImage(file='7.png')
r_bg2 = Label(image=r_bg)
r_bg2.grid(row=0, column=0)

l1 = Label(root, text='Register Form', bg='white', fg='blue', font=('Arial', 15, 'bold'))
l1.place(x=588, y=110)

l2 = Label(root, text='User Name', bg='white', fg='blue', font=('Arial', 10, 'bold'))
l2.place(x=500, y=180)

t1 = Entry(root, width=50)
t1.place(x=500, y=200)


l3 = Label(root, text='Password', bg='white', fg='blue', font=('Arial', 10, 'bold'))
l3.place(x=500, y=230)

t2 = Entry(root, width=50, show='*')
t2.place(x=500, y=250)

l4 = Label(root, text='Confirm Password', bg='white', fg='blue', font=('Arial', 10, 'bold'))
l4.place(x=500, y=280)

t3 = Entry(root, width=50, show='*')
t3.place(x=500, y=300)

btn1 = Button(root, text='Submit', bg='blue', font=('', 13, 'bold'), width=30, fg='white', cursor='hand2', command=register)
btn1.place(x=500, y=350)

l5 = Label(root, text='Already Registered?', bg='white', fg='blue', font=('Arial', 10, ''))
l5.place(x=530, y=400)

btn2 = Button(root, text='Login', bg='white', font=('', 10, 'bold'), fg='blue', bd=0, activebackground='white', cursor='hand2', command=login_page)
btn2.place(x=655, y=397)

root.mainloop()
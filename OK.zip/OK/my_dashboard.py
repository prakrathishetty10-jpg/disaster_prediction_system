from tkinter import *
from tkinter import messagebox
import pymysql

con = pymysql.connect(host='localhost', user='root', password='root')
sql = con.cursor()
sql.execute('use mini_project')

#functions

#main code
root = Tk()
root.geometry()
root.title("My Dashboard")
root.resizable(False, False)
root.state('zoomed')



l1 = Label(root, text='Welcome\nto\nMy Dashboard', bg='white', fg='blue', font=('Arial', 25, 'bold'))
l1.place(x=645, y=350)



root.mainloop()